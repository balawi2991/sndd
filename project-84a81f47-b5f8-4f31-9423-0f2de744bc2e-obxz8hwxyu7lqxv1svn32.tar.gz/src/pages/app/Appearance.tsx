import React, { useState } from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import AppearanceControls from '@/components/appearance/AppearanceControls';
import LivePreview from '@/components/appearance/LivePreview';

const Appearance = () => {
  const [config, setConfig] = useState({
    logo: '',
    primaryColor: '#17B26A',
    position: 'center-bottom',
    glowingBorder: true,
    avatar: '',
    showFloatingAvatar: true,
    title: 'Chat with us',
    placeholder: 'Type your message...',
    suggestedQuestions: [
      'How can I get started?',
      'What are your pricing plans?',
      'Do you offer support?',
    ],
  });

  return (
    <div className="flex flex-col h-full w-full">
      <header className="sticky top-0 z-10 flex items-center gap-4 border-b border-gray-200 bg-white px-6 py-4">
        <SidebarTrigger />
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Appearance</h1>
          <p className="text-sm text-gray-600">Customize your chat widget</p>
        </div>
      </header>

      <main className="flex-1 overflow-auto p-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AppearanceControls config={config} setConfig={setConfig} />
            <LivePreview config={config} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Appearance;